﻿using System;
using System.Net.Http;
using System.Threading.Tasks;


/// To run this example:
/// $ dotnet run https://qa.publisher-api.news.apple.com
///
/// Which should return an error, because we haven't signed the request yet.
/// 401
/// {
///   "errors":[
///     {
///       "code":"UNAUTHORIZED"
///     }
///   ]
/// }


namespace PublisherAPI
{
    /// <summary>Class <c>PublisherAPI</c> Communicate with the 
    /// Publisher API Server</summary>
    public class PublisherAPI
    {
        /// <summary>This is the entry point of the PublisherAPI
        /// program
        /// <example>For example:
        /// <code>
        ///    dotnet run https://qa.publisher-api.news.apple.com
        /// </code>
        ///   {
        ///   "errors":[
        ///     {
        ///       "code":"UNAUTHORIZED"
        ///     }
        ///   ]
        /// }
        /// </example>
        /// </summary>
        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                System.Console.WriteLine("no or missing arguments");
                System.Environment.Exit(0);
            }

            string url = args[0];

            var readChannelResponse = Task.Run(() => readChannel(url));
            readChannelResponse.Wait();

            Console.WriteLine(readChannelResponse.Result);
            System.Environment.Exit(0);
        }

        /// <summary>This method starts the string of events
        /// that builds data, communicates to the server
        /// and returns the results
        /// </summary>
        static Task<string> readChannel(string url)
        {
            var sendRequestResponse = Task.Run(() => sendRequest("GET", url));
            sendRequestResponse.Wait();
            return sendRequestResponse;
        }

        /// <summary>This method builds the HttpClient
        /// request, sends the data and returns the results
        /// </summary>
        static async Task<string> sendRequest(string method, string url)
        {
            string result;

            HttpClient client = new HttpClient();

            HttpResponseMessage response = await client.GetAsync(url);
            HttpContent content = response.Content;
            {
                result = await content.ReadAsStringAsync();
            }

            return result;
        }
    }
}
