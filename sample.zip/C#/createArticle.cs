﻿using System;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.Linq;

/// To run this example:
/// $ dotnet run https://qa.publisher-api.news.apple.com
///
/// Which should return an error, because we haven't signed the request yet.
/// {
///   "data":{
///     "createdAt":"2016-06-13T00:25:43Z",
///     "modifiedAt":"2016-06-13T23:30:05Z",
///     "id":"4cf91021-f696-4706-81bd-2f799f6fb40a",
///     "type":"channel",
///     "shareUrl":"https://apple.news/TESx4XIzZMi1kL2Q29Q2ghh",
///   ...
/// }
namespace PublisherAPI
{
    /// <summary>Class <c>PublisherAPI</c> Communicate with the 
    /// Publisher API Server</summary>
    public class PublisherAPI
    {
        /// <summary>This is the entry point of the PublisherAPI
        /// program
        /// <example>For example:
        /// <code>
        ///    dotnet run https://qa.publisher-api.news.apple.com
        /// </code>
        /// {
        ///   "data":{
        ///     "createdAt":"2016-06-13T00:25:43Z",
        ///     "modifiedAt":"2016-06-13T23:30:05Z",
        ///     "id":"4cf91021-f696-4706-81bd-2f799f6fb40a",
        ///     "type":"channel",
        ///     "shareUrl":"https://apple.news/TESx4XIzZMi1kL2Q29Q2ghh",
        ///   ...
        /// }
        /// </example>
        /// </summary>
        static void Main(string[] args)
        {
            if (args.Length < 4)
            {
                System.Console.WriteLine("no or missing arguments");
                System.Environment.Exit(0);
            }

            string url = args[0] + "/channels/" + args[1];
            string keyId = args[2];
            string keySecret = args[3];
            string currentAction = "readChannel";
            string articleDirectory = "";

            if (args.Length == 5)
            {
                currentAction = "createArticle";
                articleDirectory = args[4];
            }

            switch (currentAction)
            {
                case "readChannel":
                    var readChannelResponse = Task.Run(() => readChannel(url, keyId, keySecret));
                    readChannelResponse.Wait();

                    Console.WriteLine(readChannelResponse.Result);
                    System.Environment.Exit(0);
                    break;

                case "createArticle":
                    var createArticleResponse = Task.Run(() => createArticle(url, keyId, keySecret, articleDirectory));
                    createArticleResponse.Wait();

                    Console.WriteLine(createArticleResponse.Result);
                    System.Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("{'errors':[{'code':'UNKNOWN_COMMAND'}]}");
                    break;
            }
        }
        /// <summary>This method starts the string of events
        /// that builds data, communicates to the server
        /// and returns the results
        /// </summary>
        static Task<string> readChannel(string url, string keyId, string keySecret)
        {
            var sendRequestResponse = Task.Run(() => sendRequest("GET", url, keyId, keySecret));
            sendRequestResponse.Wait();
            return sendRequestResponse;
        }

        /// <summary>This method calls methods to build and send the article
        /// package.
        /// Returns the Publisher API response
        /// </summary>
        static Task<string> createArticle(string url, string keyId, string keySecret, string articleDirectory)
        {
            string createUrl = url + "/articles";

            Tuple<byte[], string> buildArticleBodyResult = buildArticleBody(articleDirectory);

            byte[] body = buildArticleBodyResult.Item1;
            string contentType = buildArticleBodyResult.Item2;

            var requestResults = Task.Run(() => sendRequest("POST", createUrl, keyId, keySecret, body, contentType));
            requestResults.Wait();

            return requestResults;
        }

        /// <summary>This method is a simple randon string generator
        /// Returns a 32 bit random string
        /// </summary>        
        static string RandomString()
        {
            Random rand = new Random((int)DateTime.Now.Ticks);
            string input = "abcdefghijklmnopqrstuvwxyz0123456789";
            return new string(Enumerable.Range(0, 32).Select(x => input[rand.Next(0, input.Length)]).ToArray());
        }

        /// <summary>Merges 2 byte arrays
        /// Returns new byte array
        /// </summary>        
        static byte[] mergeByteArrays(byte[] byteArr1, byte[] byteArr2)
        {
            byte[] newByteArray = new byte[byteArr1.Length + byteArr2.Length];
            System.Buffer.BlockCopy(byteArr1, 0, newByteArray, 0, byteArr1.Length);
            System.Buffer.BlockCopy(byteArr2, 0, newByteArray, byteArr1.Length, byteArr2.Length);

            return newByteArray;
        }

        /// <summary>This method creates the multi-part form that
        /// contains the article package.
        /// Returns an array of body and content type
        /// </summary>   
        static Tuple<byte[], string> buildArticleBody(string articleDirectory)
        {
            string boundary = RandomString();

            string contentType = "multipart/form-data; boundary=" + boundary;

            string[] filenames = Directory.GetFiles(articleDirectory);

            if (filenames == null || filenames.Length == 0)
            {
                Console.WriteLine(articleDirectory + " doesn't appear to be a valid article bundle!");
                System.Environment.Exit(0);
            }

            byte[] body = new byte[0];

            foreach (string fileName in filenames)
            {
                byte[] buildMimePartResult = buildMimePart(fileName, boundary);

                if (buildMimePartResult != null && buildMimePartResult.Length > 0)
                {
                    body = mergeByteArrays(body, buildMimePartResult);
                }
            }

            body = mergeByteArrays(body, Encoding.UTF8.GetBytes($"--{boundary}--"));

            return Tuple.Create<byte[], string>(body, contentType);
        }

        /// <summary>This method loops thought each file in the article
        /// package and builds the multi-part for that particular file.
        /// Returns the multi part for that given file.
        /// </summary>  
        static byte[] buildMimePart(string fileNameWithPath, string boundry)
        {
            FileInfo fileInfo = new FileInfo(fileNameWithPath);
            string fileExtension = fileInfo.Extension;
            string fileName = fileInfo.Name;
            string nameWithoutExtension = Path.GetFileNameWithoutExtension(fileNameWithPath);
            long fileSize = fileInfo.Length;

            string contentType = guessContentType(fileName, fileExtension);

            if (contentType == "none")
            {
                return null;
            }

            byte[] part = new byte[0];

            part = mergeByteArrays(part, Encoding.UTF8.GetBytes($"--{boundry}\r\n"));

            part = mergeByteArrays(part, Encoding.UTF8.GetBytes($"Content-Type: {contentType}\r\n"));

            if (fileName == "metadata.json")
            {
                part = mergeByteArrays(part, Encoding.UTF8.GetBytes($"Content-Disposition: form-data; name=metadata; size={fileSize}\r\n\r\n"));
            }
            else
            {
                part = mergeByteArrays(part, Encoding.UTF8.GetBytes($"Content-Disposition: form-data; filename={fileName}; size={fileSize}\r\n\r\n"));
            }

            byte[] data = File.ReadAllBytes(fileNameWithPath);

            if (fileExtension == ".json")
            {
                part = mergeByteArrays(part, Encoding.UTF8.GetBytes(System.Text.Encoding.UTF8.GetString(data)));
            }
            else
            {
                part = mergeByteArrays(part, data);
            }

            part = mergeByteArrays(part, Encoding.UTF8.GetBytes("\r\n"));

            return part;
        }

        /// <summary>This method determines the mimetype based on
        /// the file extension or filename.
        /// Returns the mime type for that given file.
        /// </summary> 
        static string guessContentType(string fileName, string fileExtension)
        {
            if (fileName == "article.json" || fileName == "metadata.json")
            {
                return "application/json";
            }
            else
            {
                string mimeType;
                switch (fileExtension)
                {
                    case ".jpg":
                    case ".jpeg":
                        mimeType = "image/jpeg";
                        break;
                    case ".gif":
                        mimeType = "image/gif";
                        break;
                    case ".png":
                        mimeType = "image/png";
                        break;
                    default:
                        mimeType = "none";
                        break;
                };
                return mimeType;
            }
        }

        /// <summary>This method builds a signature based on the
        /// publisher's secret key and the request data.
        /// Returns the signature key
        /// </summary>
        static string createSignature(byte[] messageBytes, string secret)
        {
            var encoding = new System.Text.UTF8Encoding();
            byte[] keyByte = Convert.FromBase64String(secret);

            using (var hmacsha256 = new HMACSHA256(keyByte))
            {
                return Convert.ToBase64String(hmacsha256.ComputeHash(messageBytes));
            }
        }

        /// <summary>This method builds the HttpClient
        /// request, sends the data and returns the results
        /// </summary>
        static async Task<string> sendRequest(string method, string url, string keyId, string keySecret, byte[] body = null, string contentType = null)
        {
            string result;
            string date = DateTime.Now.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ssZ");
            string canonicalRequest = method + url + date;

            byte[] canonicalRequestBytes = Encoding.ASCII.GetBytes(canonicalRequest);

            if (body != null && body.Length > 0)
            {
                byte[] contentTypeBytes = Encoding.ASCII.GetBytes(contentType);
                canonicalRequestBytes = mergeByteArrays(canonicalRequestBytes, contentTypeBytes);
                canonicalRequestBytes = mergeByteArrays(canonicalRequestBytes, body);
            }

            var signature = Task.Run(() => createSignature(canonicalRequestBytes, keySecret));
            signature.Wait();

            string authorization = "HHMAC; key=" + keyId + "; signature=" + signature.Result + "; date=" + date;

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", authorization);

            if (method == "GET")
            {
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, url);
                HttpResponseMessage response = await client.SendAsync(request);
                HttpContent content = response.Content;
                {
                    result = await content.ReadAsStringAsync();
                }
            }
            else
            {
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new ByteArrayContent(body);
                request.Content.Headers.Add("Content-Type", contentType);

                HttpResponseMessage response = await client.SendAsync(request);
                HttpContent content = response.Content;
                {
                    result = await content.ReadAsStringAsync();
                }
            }

            return result;
        }
    }
}
