﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Security.Cryptography;

/// To run this example:
/// $ dotnet run https://qa.publisher-api.news.apple.com
///
/// Which should return an error, because we haven't signed the request yet.
/// {
///   "data":{
///     "createdAt":"2016-06-13T00:25:43Z",
///     "modifiedAt":"2016-06-13T23:30:05Z",
///     "id":"4cf91021-f696-4706-81bd-2f799f6fb40a",
///     "type":"channel",
///     "shareUrl":"https://apple.news/TESx4XIzZMi1kL2Q29Q2ghh",
///   ...
/// }
namespace PublisherAPI
{
    /// <summary>Class <c>PublisherAPI</c> Communicate with the 
    /// Publisher API Server</summary>
    public class PublisherAPI
    {
        /// <summary>This is the entry point of the PublisherAPI
        /// program
        /// <example>For example:
        /// <code>
        ///    dotnet run https://qa.publisher-api.news.apple.com
        /// </code>
        /// {
        ///   "data":{
        ///     "createdAt":"2016-06-13T00:25:43Z",
        ///     "modifiedAt":"2016-06-13T23:30:05Z",
        ///     "id":"4cf91021-f696-4706-81bd-2f799f6fb40a",
        ///     "type":"channel",
        ///     "shareUrl":"https://apple.news/TESx4XIzZMi1kL2Q29Q2ghh",
        ///   ...
        /// }
        /// </example>
        /// </summary>
        static void Main(string[] args)
        {
            if (args.Length < 4)
            {
                System.Console.WriteLine("no or missing arguments");
                System.Environment.Exit(0);
            }

            string url = args[0] + "/channels/" + args[1];
            string keyId = args[2];
            string keySecret = args[3];
            string currentAction = "readChannel";

            if (args.Length == 5)
            {
                currentAction = "createArticle";
            }

            switch (currentAction)
            {
                case "readChannel":
                    var readChannelResponse = Task.Run(() => readChannel(url, keyId, keySecret));
                    readChannelResponse.Wait();

                    Console.WriteLine(readChannelResponse.Result);
                    System.Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("{'errors':[{'code':'UNKNOWN_COMMAND'}]}");
                    break;
            }
        }
        /// <summary>This method starts the string of events
        /// that builds data, communicates to the server
        /// and returns the results
        /// </summary>
        static Task<string> readChannel(string url, string keyId, string keySecret)
        {
            var sendRequestResponse = Task.Run(() => sendRequest("GET", url, keyId, keySecret));
            sendRequestResponse.Wait();
            return sendRequestResponse;
        }

        /// <summary>This method builds a signature based on the
        /// publisher's secret key and the request data.
        /// Returns the signature key
        /// </summary>
        static string createSignature(string message, string secret)
        {
            var encoding = new System.Text.UTF8Encoding();
            byte[] keyByte = Convert.FromBase64String(secret);

            byte[] messageBytes = encoding.GetBytes(message);
            using (var hmacsha256 = new HMACSHA256(keyByte))
            {
                return Convert.ToBase64String(hmacsha256.ComputeHash(messageBytes));
            }
        }

        /// <summary>This method builds the HttpClient
        /// request, sends the data and returns the results
        /// </summary>
        static async Task<string> sendRequest(string method, string url, string keyId, string keySecret)
        {
            string result;
            string date = DateTime.Now.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ssZ");
            string canonicalRequest = method + url + date;

            var signature = Task.Run(() => createSignature(canonicalRequest, keySecret));
            signature.Wait();

            string authorization = "HHMAC; key=" + keyId + "; signature=" + signature.Result + "; date=" + date;

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", authorization);

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, url);
            HttpResponseMessage response = await client.SendAsync(request);
            HttpContent content = response.Content;
            {
                result = await content.ReadAsStringAsync();
            }

            return result;
        }
    }
}
